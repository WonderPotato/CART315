using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CannonControl : MonoBehaviour {

    public float RotateSpeed;
    public Transform BallPrefab;
    public Transform SpawnPoint;
    public float ShootForce;
    public Material[] mat;
    public Renderer CanonRenderer;
  //  public float colourChangeDelay = 0.5f;
    //float currentDelay = 0f;
 //   bool colourChangeCollision = false;
    // public Spawn04[] mat;

    // Use this for initialization
    void Start() {

        /*   int random = GetRandomValue(
           new RandomSelection(0, 5, .1f),     //brick
           new RandomSelection(6, 8, .15f),     //rainbow    
           new RandomSelection(9, 10, .2175f),    //Red
           new RandomSelection(10, 20, .2175f),              //green 
           new RandomSelection(21,30, .2175f),              //blue
           new RandomSelection(31, 40, .2175f)               //yellow
       );*/
        ChangeColor();

    }

    // Update is called once per frame
    void Update() {

        if (Input.GetKey(KeyCode.RightArrow) == true) {

            transform.Rotate(new Vector3(0, 0, -RotateSpeed));

        }
        if (Input.GetKey(KeyCode.LeftArrow) == true) {

            transform.Rotate(new Vector3(0, 0, RotateSpeed));

        }
        if (Input.GetKeyDown(KeyCode.Space) == true) {

            Transform NewBall = Instantiate(BallPrefab);
            NewBall.position = SpawnPoint.position;
            NewBall.rotation = SpawnPoint.rotation;
            NewBall.GetComponent<Renderer>().material = CanonRenderer.material;

            Vector3 DirectionVector = SpawnPoint.position - transform.position;
            DirectionVector = DirectionVector * ShootForce;
            NewBall.GetComponent<Rigidbody>().AddForce(DirectionVector);
 
            ChangeColor();
            GetComponent<AudioSource>().Play();
           
        }

     }

    void ChangeColor() {

        //balls are in materials
        //therefore create an array of length 5 and create the appropriate probabilities into a function
        //brick ball 10% chance
        //rainbow ball 5% chance
        //colors R: Y: G; B:

        int chosenMaterial = Random.Range(0, mat.Length);
        CanonRenderer.material = mat[chosenMaterial];

    }

 
    }
    
  

    //brick.mat material element
   // private void OnCollisionEnter(Collision colColor)
   // {
   //     if (colColor.chosenMaterial.tag == ")
   // }
    /*    struct RandommSelection
        {

            private int minValue;
            private int maxValue;
            public float probability;

            public RandomSelection(int minValue, int maxValue, float probability)
            {
                this.minValue = minValue;
                this.maxValue = maxValue;
                this.probability = probability;

            }

            public int GetValue()
            {

                return Random.Range(minValue, maxValue + 1);
            }


        }
        */
        


    ///probability where brick and raindow ball have lower chancces of being picked, therefore their results will be rare but effective
  
    //brick ball when collide, any ball it touches turns to black - therefore unable to score points or eliminate
    //brick.mat changes color upon collision
    //sphere collider trigger 
    //element4
    //SetColor(col.tranform, Color.black)
    //change color upon impact
    /// https://answers.unity.com/questions/806099/change-objects-color-upon-collision.html      
    /// some references 
    /// 0-1
    /// 0.1
    /// 0.15
    /// 0.1875
    /*   /// 0.1875
       /// 0.1875
       /// 0.1875
       /// int randomize 
       /// random.vlue.0.1
       /// if(randomize < random.value.0.1)
       /// 1-0.1
       ///    (Random.Range(value.0.1);
       /// var element = myArray[Random.Range(0, myArray.Length)];
       ///  float Choose (float[] probs) {
       int randomize;

       float total = 0;

       foreach (float elem in probs)
       {
           total += elem;
       }

       float randomPoint = Random.value * total;

       for (int i = 0; i < probs.Length; i++)
       {
           if (randomPoint < probs[i])
           {
               return i;       //return brick
           }
           else
           {
               randomPoint -= probs[i];
           }
       }
       return probs.Length - 1;
   }

   
   */

    
    //void BallProbability() {


    //}

    /*
        void SpawnMaterials()
    {
        int i = Random.Range(0, 100);
        for (int j = 0; j < MatchTargetWeightMask.Length; j++)
        {
            if(i >= mat[j].minProbabilityRange && i <= mat[j].maxProbabilityRange)
            {
                Instantiate(mat[j].spawnObject, transform.position, transform.rotation);
                break;
            }


        }
    }
    */
    /*
    [System.Serializable]
    public class Spawn04
    {
        public GameObject SpawnObject;
        public int minProbabilityRange = 0;
        public int maxProbabilityRange = 0;

    }
    */


