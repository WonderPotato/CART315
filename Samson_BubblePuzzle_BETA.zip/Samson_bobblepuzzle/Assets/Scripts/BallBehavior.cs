﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallBehavior : MonoBehaviour {

    	//public Material[] mat;
    public bool IsExploding = false;
   public  int CurrentlyCollidingSameColoredBalls = 0;
    public List<Transform> AllSameColoredBallsImCollidingWith = new List<Transform>();
    public Material rainbowMaterial;
    public Material brickMaterial;
    public Transform CubeBrick;
    //  public Transform BlockerSpawn;
   /// public GameObject brickBlock;
   // public float spawnTime = 3f;
   // public Transform[] spawnPoints;

 
    // Use this for initialization
    void Start () {
        //
        //		int chosenMaterial = Random.Range (0, mat.Length);
        //		Debug.Log("Chosen material index is: " + chosenMaterial);
        //		GetComponent<Renderer> ().material = mat [chosenMaterial];
        // startPos = transform.position;
        //InvokeRepeating("Spawn", spawnTime, spawnTime);
    }

	// Update is called once per frame
	void Update () {
     //   Vector3 v = startPos;
      //v.x += delta * Mathf.Sin(Time.time * speed);
        //CubeBrick.transform.position = v;
    }

    //void Spawn()
    //{
     //   if(GetComponent<Renderer>().material.color == brickMaterial.color)
       // {
         //   return;
        //}

        //int spawnPointIndex = Random.Range(0, spawnPoints.Length);

//        Instantiate(brickBlock, spawnPoints[spawnPointIndex].position, spawnPoints[spawnPointIndex].rotation);
  //  }
	void OnCollisionEnter(Collision col){

        		//Debug.Log ("Ball has collided with" + col.transform.tag);

        Debug.Log("The contact impulse is: " + col.impulse.magnitude);
        

        if ((col.transform.tag == "Wall") || (col.transform.tag == "Ball")) {
			GetComponent<Rigidbody>().isKinematic = true;
            GetComponent<AudioSource>().Play();
		}
        //case loop maybe?
		if (col.transform.tag == "Ball") {
			if (GetComponent<Renderer> ().material.color == col.transform.GetComponent<Renderer>().material.color) {

                CurrentlyCollidingSameColoredBalls++;
                AllSameColoredBallsImCollidingWith.Add(col.transform);
                //Am I part of a 2+ same colored colliding ball chain?
                if (CurrentlyCollidingSameColoredBalls > 1)
                {
                                       
                    Explode();
                }
               
                Debug.Log ("This object has the same material as me");

			}

           //rainbow ball works 
            if (GetComponent<Renderer>().material.color == rainbowMaterial.color)
            {
                GetComponent<Renderer>().material.color = col.transform.GetComponent<Renderer>().material.color;
                CurrentlyCollidingSameColoredBalls++;
                AllSameColoredBallsImCollidingWith.Add(col.transform);
                //Am I part of a 2+ same colored colliding ball chain?
                if (CurrentlyCollidingSameColoredBalls > 1)
                {

                    Explode();
                }

                Debug.Log("I am a newborn rainbow ball my new color is " + col.transform.GetComponent<Renderer>().material);
            }

            //brick blocker platform pop up moves left to right slashing fast 
             if (GetComponent<Renderer>().material.color == brickMaterial.color)
            {

               //
                int spawnPointX = Random.Range(-15, 20);
                int spawnPointY = Random.Range(0, 18);
                Vector3 BlockerSpawn = new Vector3(spawnPointX, spawnPointY, 0);
                Instantiate(CubeBrick);
                
                //pop up object
               
                CubeBrick.GetComponent<Rigidbody>();

              
               // DestroyImmediate(CubeBrick, true);
                //Destroy(PlatformBlocker, 5);



                if (GetComponent<Renderer>().material.color == col.transform.GetComponent<Renderer>().material.color)
                {
                    CurrentlyCollidingSameColoredBalls++;
                    AllSameColoredBallsImCollidingWith.Add(col.transform);
                    //Am I part of a 2+ same colored colliding ball chain?
                    if (CurrentlyCollidingSameColoredBalls > 1)
                    {

                        Explode();
                    }
                }

                Debug.Log("I am a brick ball with blocker platforms beware! ");
            }

        }

	}

     public void Explode()
    {
        Debug.Log("Time to explode!");

        GameObject.Find("MainManager").GetComponent<MainManager>().TotalScore++;
        GameObject.Find("MainManager").GetComponent<AudioSource>().Play();

        //Tell my friends to explode
        IsExploding = true;

        foreach (Transform ball in AllSameColoredBallsImCollidingWith)
        {
            
            if(ball.GetComponent<BallBehavior>().IsExploding == false)
            {
                ball.GetComponent<BallBehavior>().Explode();
            }           

        }

        //Explode myself

        Destroy(gameObject);

    }



}
