﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MainManager : MonoBehaviour {

    public int Timeleft = 20;


    public int TotalScore;

    private void Update()
    {
        GameObject.Find("ScoreLabel").GetComponent<Text>().text = "Score: " + TotalScore;

        if (TotalScore >= 10)
        {
            SceneManager.LoadScene("Level2");
            GameObject.Find("ScoreLabel").GetComponent<Text>().text = "Score: " + TotalScore;
            //YOU CAN PUT A PUBLIC OBJECT VARIABLE THING SO IT LOADS AFTER OR WTV LIKE IF ITS THIS MMUCH GO NEXT LEVEL
        }

        else if (TotalScore >= 30)
        {
            SceneManager.LoadScene("Level3");
            GameObject.Find("ScoreLabel").GetComponent<Text>().text = "Score: " + TotalScore;
        }
    }

    // Use this for initialization
    void Start() {

        StartCoroutine(CountDown());

    }

   

    IEnumerator CountDown()
    {
        while(Timeleft > 0)
        {
            yield return new WaitForSeconds(1);
            Timeleft--;
           

        }
    }

}
