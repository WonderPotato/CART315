﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class wallPendulum : MonoBehaviour {


    public float delta = 1.5f;      //amount to move left and right from start point
    public float speed = 2.0f;
    private Vector3 startPos;
  //  float maxValue = 15;
  //  float minValue = -15;
  //  float currentValue = 0;
   // float direction = 1;


	// Use this for initialization
	void Start () {

        startPos = transform.position;
	}
	
	// Update is called once per frame
	void Update () {
        /*
        currentValue += Time.deltaTime * direction;
        if (currentValue >= maxValue)
        {
            direction *= -1;
            currentValue = maxValue;
        } else if (currentValue <= minValue)
        {
            direction *= -1;
            currentValue = minValue;
        }
        */
        //transform.position = new Vector3(currentValue, 0, 0);
        Vector3 v = startPos;
        v.x += delta * Mathf.Sin(Time.time * speed);
        transform.position = v;


	}
}
