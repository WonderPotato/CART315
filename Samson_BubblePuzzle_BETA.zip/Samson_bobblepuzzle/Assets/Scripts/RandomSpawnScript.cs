﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomSpawnScript : MonoBehaviour {

    //prefabs to instantiate
    public GameObject prefab1, prefab2, prefab3, prefab4, prefab5;

    //public spawnRate = 2f;


	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
